-- Run this only after checking the duplicate report below.
-- 1) Find duplicate Employee IDs within a company (case-insensitive).
select company_id, lower(btrim(employee_id)) as normalized_employee_id, count(*) as duplicate_count
from public.company_members
where employee_id is not null and btrim(employee_id) <> ''
group by company_id, lower(btrim(employee_id))
having count(*) > 1;

-- 2) If the query above returns ZERO rows, run this index creation.
-- It enforces unique Employee IDs per company at database level.
create unique index if not exists company_members_company_employee_id_uidx
on public.company_members (company_id, lower(btrim(employee_id)))
where employee_id is not null and btrim(employee_id) <> '';
