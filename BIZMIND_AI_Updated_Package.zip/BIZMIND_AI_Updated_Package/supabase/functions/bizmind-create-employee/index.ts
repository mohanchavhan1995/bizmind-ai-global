import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { ...corsHeaders, "Content-Type": "application/json" },
});

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return reply({ error: "POST method required" }, 405);

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const secretKeysRaw = Deno.env.get("SUPABASE_SECRET_KEYS");
    let serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!serviceKey && secretKeysRaw) {
      try { serviceKey = JSON.parse(secretKeysRaw)?.default ?? ""; }
      catch { return reply({ error: "SUPABASE_SECRET_KEYS secret is not valid JSON" }, 500); }
    }
    if (!url || !serviceKey) return reply({ error: "Server configuration missing" }, 500);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return reply({ error: "Login required" }, 401);
    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const token = authHeader.slice(7);
    const { data: authData, error: authError } = await admin.auth.getUser(token);
    if (authError || !authData.user) return reply({ error: "Invalid login session" }, 401);
    const actorId = authData.user.id;

    const body = await req.json();
    const companyId = String(body.company_id || "").trim();
    const fullName = String(body.full_name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const employeeId = String(body.employee_id || "").trim();
    const password = String(body.password || "");
    const role = String(body.role || "").trim().toLowerCase();

    if (!companyId || !fullName || !email || !employeeId || !password) {
      return reply({ error: "Company, name, email, Employee ID and password are required" }, 400);
    }
    if (fullName.length > 120 || employeeId.length > 64 || email.length > 254) {
      return reply({ error: "One or more fields exceed the allowed length" }, 400);
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply({ error: "Enter a valid email address" }, 400);
    if (!/^[a-z0-9._-]+$/i.test(employeeId)) return reply({ error: "Employee ID may contain only letters, numbers, dot, underscore and hyphen" }, 400);
    if (!['hr', 'staff'].includes(role)) return reply({ error: "Choose HR or Staff role" }, 400);
    if (password.length < 8) return reply({ error: "Password must be at least 8 characters" }, 400);

    // Verify authority for the exact company selected in the Boss/HR dashboard.
    const { data: ownedCompany, error: bossError } = await admin.from("companies")
      .select("id").eq("id", companyId).eq("owner_id", actorId).maybeSingle();
    if (bossError) return reply({ error: "Unable to verify company ownership" }, 500);

    let actorRole: "boss" | "hr";
    if (ownedCompany) {
      actorRole = "boss";
    } else {
      const { data: membership, error: memberError } = await admin.from("company_members")
        .select("company_id, role, status").eq("company_id", companyId)
        .eq("user_id", actorId).maybeSingle();
      if (memberError) return reply({ error: "Unable to verify company membership" }, 500);
      if (!membership || membership.role !== "hr" || membership.status !== "active") {
        return reply({ error: "Only the Boss or an active HR of this company can create employees" }, 403);
      }
      actorRole = "hr";
    }
    if (actorRole === "hr" && role !== "staff") return reply({ error: "HR can create Staff accounts only" }, 403);

    const { data: existing, error: checkError } = await admin.from("company_members")
      .select("id").eq("company_id", companyId).ilike("employee_id", employeeId).limit(1);
    if (checkError) return reply({ error: "Could not check Employee ID. Verify company_members schema." }, 500);
    if (existing?.length) return reply({ error: "Employee ID already exists in this company" }, 409);

    const employeeStatus = actorRole === "hr" ? "pending" : "active";
    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { full_name: fullName, employee_id: employeeId, role },
    });
    if (createError || !created.user) return reply({ error: createError?.message || "Account creation failed" }, 400);

    const { error: insertError } = await admin.from("company_members").insert({
      company_id: companyId, user_id: created.user.id, email, full_name: fullName,
      role, employee_id: employeeId, status: employeeStatus,
    });
    if (insertError) {
      const { error: rollbackError } = await admin.auth.admin.deleteUser(created.user.id);
      if (rollbackError) console.error("Failed to roll back Auth user:", rollbackError.message);
      if (insertError.code === "23505") return reply({ error: "Employee ID or email already exists" }, 409);
      console.error("company_members insert failed:", insertError.code, insertError.message);
      return reply({ error: "Employee record could not be saved. Check company_members columns and RLS/service configuration." }, 500);
    }

    return reply({
      success: true,
      message: employeeStatus === "pending" ? "Staff account created. Waiting for Boss approval." : "Employee account created successfully.",
      employee_id: employeeId, role, status: employeeStatus, company_id: companyId,
    });
  } catch (error) {
    console.error("bizmind-create-employee error:", error);
    return reply({ error: error instanceof Error ? error.message : "Unexpected error" }, 500);
  }
});
